"""
Magento 2 Health Check implementation.

Monitors Magento 2 installations for:
- Recent orders by day
- Magento version (current vs latest)
- Security patches and vulnerabilities
- Database size
- Large folders
- var/ directory breakdown

Database credentials are automatically extracted from app/etc/env.php
if not provided in the configuration.
"""

import json
import os
import re
import time
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

from ..base import BaseCheck, CheckResult, CheckStatus
from ..registry import CheckRegistry

logger = logging.getLogger(__name__)


def parse_magento_env_php(env_php_path: str) -> Dict[str, Any]:
    """
    Parse Magento's app/etc/env.php file to extract database credentials.

    Args:
        env_php_path: Path to the env.php file

    Returns:
        Dictionary with db credentials (host, dbname, username, password, port)
        or empty dict if parsing fails
    """
    if not os.path.isfile(env_php_path):
        logger.warning(f"env.php not found at: {env_php_path}")
        return {}

    try:
        logger.info(f"Reading env.php from: {env_php_path}")
        with open(env_php_path, 'r', encoding='utf-8') as f:
            content = f.read()

        logger.debug(f"env.php file size: {len(content)} bytes")

        # Extract database configuration using regex
        # Looking for patterns like 'host' => 'localhost', 'dbname' => 'magento', etc.
        db_config = {}

        # Find the 'db' => [...] section
        # The structure is: 'db' => ['connection' => ['default' => [credentials...]]]

        # Extract host (try multiple patterns)
        host_match = re.search(r"'host'\s*=>\s*'([^']+)'", content)
        if not host_match:
            host_match = re.search(r'"host"\s*=>\s*"([^"]+)"', content)
        if host_match:
            db_config['host'] = host_match.group(1)
            logger.debug(f"Found host: {host_match.group(1)}")

        # Extract dbname (try multiple patterns)
        dbname_match = re.search(r"'dbname'\s*=>\s*'([^']+)'", content)
        if not dbname_match:
            dbname_match = re.search(r'"dbname"\s*=>\s*"([^"]+)"', content)
        if dbname_match:
            db_config['dbname'] = dbname_match.group(1)
            logger.debug(f"Found dbname: {dbname_match.group(1)}")

        # Extract username (try multiple patterns)
        username_match = re.search(r"'username'\s*=>\s*'([^']+)'", content)
        if not username_match:
            username_match = re.search(r'"username"\s*=>\s*"([^"]+)"', content)
        if username_match:
            db_config['username'] = username_match.group(1)
            logger.debug(f"Found username: {username_match.group(1)}")

        # Extract password - handle empty passwords and special characters
        # Use [^']+ instead of [^']* to require at least one character (helps with debugging)
        password_match = re.search(r"'password'\s*=>\s*'([^']*)'", content)
        if password_match:
            db_config['password'] = password_match.group(1)
            logger.debug(f"Found password in env.php (single quotes, length: {len(password_match.group(1))})")
        else:
            # Try double quotes
            password_match = re.search(r'"password"\s*=>\s*"([^"]*)"', content)
            if password_match:
                db_config['password'] = password_match.group(1)
                logger.debug(f"Found password in env.php (double quotes, length: {len(password_match.group(1))})")
            else:
                logger.warning("Password field not found in env.php - connection will fail")

        # Extract port (optional, defaults to 3306)
        port_match = re.search(r"'port'\s*=>\s*'?(\d+)'?", content)
        if port_match:
            db_config['port'] = int(port_match.group(1))

        # Handle host:port format (e.g., 'host' => 'localhost:3307')
        if 'host' in db_config and ':' in db_config['host']:
            host_parts = db_config['host'].split(':')
            db_config['host'] = host_parts[0]
            if len(host_parts) > 1 and host_parts[1].isdigit():
                db_config['port'] = int(host_parts[1])

        if db_config:
            logger.info(f"Successfully parsed env.php - found db: {db_config.get('dbname')}, user: {db_config.get('username')}, host: {db_config.get('host')}")

        return db_config

    except Exception as e:
        logger.error(f"Error parsing env.php: {e}")
        return {}

# Known Magento 2 versions - latest stable versions
# Update this list periodically
MAGENTO_VERSIONS = {
    "2.4.7": {"release_date": "2024-04-09", "security_patches": []},
    "2.4.6": {"release_date": "2023-03-14", "security_patches": ["p1", "p2", "p3", "p4", "p5", "p6"]},
    "2.4.5": {"release_date": "2022-08-09", "security_patches": ["p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8"]},
    "2.4.4": {"release_date": "2022-04-12", "security_patches": ["p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8", "p9"]},
    "2.4.3": {"release_date": "2021-08-10", "security_patches": ["p1", "p2", "p3"]},
    "2.4.2": {"release_date": "2021-02-09", "security_patches": ["p1", "p2"]},
    "2.4.1": {"release_date": "2020-10-15", "security_patches": ["p1"]},
    "2.4.0": {"release_date": "2020-07-28", "security_patches": ["p1"]},
}

LATEST_MAGENTO_VERSION = "2.4.7"


def format_bytes(bytes_val: int) -> str:
    """Format bytes to human-readable string."""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_val < 1024:
            return f"{bytes_val:.2f} {unit}"
        bytes_val /= 1024
    return f"{bytes_val:.2f} PB"


def get_directory_size(path: str) -> Tuple[int, int]:
    """
    Get directory size and file count.

    Returns:
        Tuple of (size_in_bytes, file_count)
    """
    total_size = 0
    file_count = 0

    try:
        for dirpath, dirnames, filenames in os.walk(path):
            for filename in filenames:
                filepath = os.path.join(dirpath, filename)
                try:
                    if not os.path.islink(filepath):
                        total_size += os.path.getsize(filepath)
                        file_count += 1
                except (OSError, PermissionError):
                    pass
    except (OSError, PermissionError) as e:
        logger.warning(f"Error scanning directory {path}: {e}")

    return total_size, file_count


@CheckRegistry.register('MAGENTO_HEALTH')
class MagentoHealthCheck(BaseCheck):
    """
    Comprehensive Magento 2 health monitoring check.

    Gathers:
    1. Recent orders by day
    2. Magento version status
    3. Security patches and vulnerabilities
    4. Database size
    5. Top 5 large folders
    6. var/ directory breakdown
    """

    @property
    def name(self) -> str:
        return "Magento 2 Health"

    @property
    def category(self) -> str:
        return "cms"

    def execute(self) -> CheckResult:
        """Execute all Magento health checks."""
        start_time = time.time()

        try:
            magento_root = self.config.get('magento_root')
            if not magento_root:
                return CheckResult(
                    status=CheckStatus.ERROR,
                    score=0,
                    message="magento_root path is required",
                    duration=time.time() - start_time
                )

            if not os.path.isdir(magento_root):
                return CheckResult(
                    status=CheckStatus.ERROR,
                    score=0,
                    message=f"Magento root directory not found: {magento_root}",
                    duration=time.time() - start_time
                )

            # Gather all check results
            details: Dict[str, Any] = {
                "magento_root": magento_root,
                "checked_at": datetime.utcnow().isoformat(),
            }

            issues: List[str] = []
            warnings: List[str] = []

            # 1. Check orders (if DB credentials provided)
            if self.config.get('check_orders', True):
                orders_result = self._check_orders()
                details['orders'] = orders_result
                if orders_result.get('error'):
                    warnings.append(f"Orders check failed: {orders_result['error']}")
                elif orders_result.get('warning'):
                    warnings.append(orders_result['warning'])

            # 2. Check version
            if self.config.get('check_version', True):
                version_result = self._check_version(magento_root)
                details['version'] = version_result
                if version_result.get('is_outdated'):
                    if version_result.get('versions_behind', 0) >= 2:
                        issues.append(f"Magento version is critically outdated: {version_result.get('current_version')} (latest: {version_result.get('latest_version')})")
                    else:
                        warnings.append(f"Magento version is outdated: {version_result.get('current_version')} (latest: {version_result.get('latest_version')})")

            # 3. Check security
            if self.config.get('check_security', True):
                security_result = self._check_security(magento_root)
                details['security'] = security_result
                if security_result.get('risk_level') == 'critical':
                    issues.append("Critical security vulnerabilities detected")
                elif security_result.get('risk_level') == 'high':
                    warnings.append("Security issues detected")

            # 4. Check database size
            if self.config.get('check_database_size', True):
                db_result = self._check_database_size()
                details['database'] = db_result
                if db_result.get('error'):
                    warnings.append(f"Database check failed: {db_result['error']}")
                else:
                    warning_gb = self.config.get('database_size_warning_gb', 10)
                    size_gb = db_result.get('database_size_bytes', 0) / (1024**3)
                    if size_gb > warning_gb:
                        warnings.append(f"Database size ({size_gb:.1f} GB) exceeds warning threshold ({warning_gb} GB)")

            # 5. Check large folders
            if self.config.get('check_large_folders', True):
                folders_result = self._check_large_folders(magento_root)
                details['large_folders'] = folders_result

            # 6. Check var/ directory
            if self.config.get('check_var_directory', True):
                var_result = self._check_var_directory(magento_root)
                details['var_breakdown'] = var_result
                if var_result.get('total_var_size'):
                    warning_gb = self.config.get('var_size_warning_gb', 5)
                    var_size_gb = var_result['total_var_size_bytes'] / (1024**3)
                    if var_size_gb > warning_gb:
                        warnings.append(f"var/ directory size ({var_size_gb:.1f} GB) exceeds warning threshold ({warning_gb} GB)")

            # 7. Check cache status
            if self.config.get('check_cache_status', True):
                cache_result = self._check_cache_status()
                details['cache'] = cache_result
                if cache_result.get('error'):
                    warnings.append(f"Cache status check failed: {cache_result['error']}")
                elif cache_result.get('disabled_count', 0) > 0:
                    warnings.append(f"{cache_result['disabled_count']} cache type(s) disabled")

            # 8. Check indexer status
            if self.config.get('check_indexer_status', True):
                indexer_result = self._check_indexer_status()
                details['indexers'] = indexer_result
                if indexer_result.get('error'):
                    warnings.append(f"Indexer status check failed: {indexer_result['error']}")
                elif indexer_result.get('invalid_count', 0) > 0:
                    warnings.append(f"{indexer_result['invalid_count']} indexer(s) require reindex")

            # Determine overall status and score
            if issues:
                status = CheckStatus.CRITICAL
                score = 30
                message = f"Critical issues found: {'; '.join(issues)}"
            elif warnings:
                status = CheckStatus.WARNING
                score = 70
                message = f"Warnings: {'; '.join(warnings)}"
            else:
                status = CheckStatus.PASSED
                score = 100
                message = "All Magento health checks passed"

            details['issues'] = issues
            details['warnings'] = warnings

            return CheckResult(
                status=status,
                score=score,
                message=message,
                details=details,
                duration=time.time() - start_time
            )

        except Exception as e:
            logger.exception("Magento health check failed")
            return CheckResult(
                status=CheckStatus.ERROR,
                score=0,
                message=f"Check failed: {str(e)}",
                duration=time.time() - start_time
            )

    def _get_db_credentials(self) -> Dict[str, Any]:
        """
        Get database credentials from config or env.php.

        Priority:
        1. Explicitly provided config values
        2. Values from app/etc/env.php

        Returns:
            Dict with host, port, dbname, username, password
        """
        # Try to get credentials from env.php first
        magento_root = self.config.get('magento_root', '')
        env_php_path = os.path.join(magento_root, 'app', 'etc', 'env.php')
        env_credentials = parse_magento_env_php(env_php_path)

        # Use config values if provided, otherwise fall back to env.php values
        credentials = {
            'host': self.config.get('db_host') or env_credentials.get('host', 'localhost'),
            'port': self.config.get('db_port') or env_credentials.get('port', 3306),
            'dbname': self.config.get('db_name') or env_credentials.get('dbname'),
            'username': self.config.get('db_user') or env_credentials.get('username'),
            'password': self.config.get('db_password') if self.config.get('db_password') is not None else env_credentials.get('password'),
        }

        return credentials

    def _get_db_connection(self):
        """
        Get MySQL database connection.

        Credentials are obtained from config or automatically from env.php.

        Returns database connection or None if connection fails.
        """
        try:
            import mysql.connector
        except ImportError:
            logger.error("mysql-connector-python not installed")
            return None

        credentials = self._get_db_credentials()

        db_host = credentials.get('host', 'localhost')
        db_port = credentials.get('port', 3306)
        db_name = credentials.get('dbname')
        db_user = credentials.get('username')
        db_password = credentials.get('password')

        # Log credentials for debugging (mask password)
        logger.debug(f"DB Connection attempt - Host: {db_host}, Port: {db_port}, DB: {db_name}, User: {db_user}, Password: {'***' if db_password else 'NOT SET'}")

        if not db_name or not db_user:
            logger.warning(f"Database credentials not available - DB: {db_name}, User: {db_user} (neither provided in config nor found in env.php)")
            return None

        # Password can be empty string (though not recommended)
        if db_password is None:
            logger.warning("Database password not found in config or env.php")
            return None

        # Try TCP connection first
        try:
            logger.debug(f"Attempting TCP connection to {db_host}:{db_port}")
            conn = mysql.connector.connect(
                host=db_host,
                port=db_port,
                database=db_name,
                user=db_user,
                password=db_password,
                connect_timeout=30
            )
            logger.info(f"Successfully connected to database via TCP: {db_name}@{db_host}:{db_port}")
            return conn
        except mysql.connector.Error as e:
            logger.warning(f"TCP connection failed (Error {e.errno}: {e.msg}), trying Unix socket...")

            # If TCP fails and host is localhost/127.0.0.1, try Unix socket
            if db_host in ['localhost', '127.0.0.1']:
                common_sockets = [
                    '/var/run/mysqld/mysqld.sock',
                    '/tmp/mysql.sock',
                    '/var/lib/mysql/mysql.sock'
                ]

                for socket_path in common_sockets:
                    if not os.path.exists(socket_path):
                        continue

                    try:
                        logger.debug(f"Attempting Unix socket connection: {socket_path}")
                        conn = mysql.connector.connect(
                            unix_socket=socket_path,
                            database=db_name,
                            user=db_user,
                            password=db_password,
                            connect_timeout=30
                        )
                        logger.info(f"Successfully connected to database via Unix socket: {socket_path}")
                        return conn
                    except mysql.connector.Error as sock_err:
                        logger.debug(f"Socket {socket_path} failed: {sock_err.msg}")
                        continue

            logger.error(f"All connection attempts failed - Last error code: {e.errno}, Message: {e.msg}")
            return None
        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            return None

    def _check_orders(self) -> Dict[str, Any]:
        """Check recent orders from database."""
        conn = self._get_db_connection()
        if not conn:
            return {"error": "Database connection not available"}

        try:
            cursor = conn.cursor(dictionary=True)
            days_to_check = self.config.get('orders_days_to_check', 7)

            # Get table prefix from env.php
            magento_root = self.config.get('magento_root', '')
            env_php_path = os.path.join(magento_root, 'app', 'etc', 'env.php')

            # Try to get table prefix from env.php
            table_prefix = ''
            try:
                with open(env_php_path, 'r') as f:
                    content = f.read()
                    prefix_match = re.search(r"'table_prefix'\s*=>\s*'([^']*)'", content)
                    if prefix_match:
                        table_prefix = prefix_match.group(1)
                        logger.debug(f"Found table prefix: '{table_prefix}'")
            except Exception as e:
                logger.debug(f"Could not read table prefix from env.php: {e}")

            # First, check if there are ANY orders in the table
            check_query = f"SELECT COUNT(*) as total FROM {table_prefix}sales_order"
            logger.info(f"Checking total orders with query: {check_query}")
            cursor.execute(check_query)
            total_check = cursor.fetchone()
            total_in_db = total_check.get('total', 0) if total_check else 0
            logger.info(f"Total orders in database: {total_in_db}")

            # If no orders at all, return early
            if total_in_db == 0:
                cursor.close()
                conn.close()
                return {
                    "orders_by_day": [],
                    "total_orders_period": 0,
                    "total_revenue_period": 0,
                    "average_orders_per_day": 0,
                    "days_checked": days_to_check,
                    "total_orders_in_database": 0,
                    "info": "No orders found in sales_order table"
                }

            # Check the date range of existing orders
            date_range_query = f"""
                SELECT
                    MIN(created_at) as oldest_order,
                    MAX(created_at) as newest_order,
                    CURDATE() as today,
                    DATE_SUB(CURDATE(), INTERVAL %s DAY) as cutoff_date
                FROM {table_prefix}sales_order
            """
            cursor.execute(date_range_query, (days_to_check,))
            date_range = cursor.fetchone()
            logger.info(f"Order date range: oldest={date_range.get('oldest_order')}, newest={date_range.get('newest_order')}, today={date_range.get('today')}, cutoff={date_range.get('cutoff_date')}")

            # Query orders grouped by day
            query = f"""
                SELECT
                    DATE(created_at) as order_date,
                    COUNT(*) as order_count,
                    SUM(grand_total) as total_revenue
                FROM {table_prefix}sales_order
                WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
                GROUP BY DATE(created_at)
                ORDER BY order_date DESC
            """

            logger.info(f"Executing orders query for last {days_to_check} days")
            logger.debug(f"Full query: {query % days_to_check}")
            cursor.execute(query, (days_to_check,))
            rows = cursor.fetchall()
            logger.info(f"Query returned {len(rows)} rows")

            if len(rows) == 0:
                logger.warning(f"No orders in last {days_to_check} days. Check date_range above to see if orders are older.")

            orders_by_day = []
            total_orders = 0
            total_revenue = 0

            for row in rows:
                # Handle both uppercase and lowercase column names
                order_date_val = row.get('order_date') or row.get('ORDER_DATE')
                order_count_val = row.get('order_count') or row.get('ORDER_COUNT', 0)
                total_revenue_val = row.get('total_revenue') or row.get('TOTAL_REVENUE')

                order_date = order_date_val.strftime('%Y-%m-%d') if order_date_val else None
                count = int(order_count_val)
                revenue = float(total_revenue_val) if total_revenue_val else 0

                logger.debug(f"Order row: date={order_date}, count={count}, revenue={revenue}")

                orders_by_day.append({
                    "date": order_date,
                    "count": count,
                    "revenue": round(revenue, 2)
                })
                total_orders += count
                total_revenue += revenue

            avg_orders_per_day = total_orders / days_to_check if days_to_check > 0 else 0

            result = {
                "orders_by_day": orders_by_day,
                "total_orders_period": total_orders,
                "total_revenue_period": round(total_revenue, 2),
                "average_orders_per_day": round(avg_orders_per_day, 1),
                "days_checked": days_to_check,
                "total_orders_in_database": total_in_db
            }

            # Add info message if no orders in period but orders exist in DB
            if total_orders == 0 and total_in_db > 0:
                result['info'] = f"No orders in the last {days_to_check} days, but {total_in_db} orders exist in database (older orders)"

            # Check warning threshold
            warning_threshold = self.config.get('orders_warning_threshold')
            if warning_threshold and avg_orders_per_day < warning_threshold:
                result['warning'] = f"Average daily orders ({avg_orders_per_day:.1f}) below threshold ({warning_threshold})"

            cursor.close()
            conn.close()

            return result

        except Exception as e:
            logger.error(f"Orders check failed: {e}")
            if conn:
                conn.close()
            return {"error": str(e)}

    def _check_version(self, magento_root: str) -> Dict[str, Any]:
        """Check Magento version from composer.json."""
        composer_json_path = os.path.join(magento_root, 'composer.json')
        composer_lock_path = os.path.join(magento_root, 'composer.lock')

        current_version = None

        # Try composer.lock first (more accurate)
        if os.path.isfile(composer_lock_path):
            try:
                with open(composer_lock_path, 'r') as f:
                    lock_data = json.load(f)
                    for package in lock_data.get('packages', []):
                        if package.get('name') == 'magento/product-community-edition':
                            current_version = package.get('version', '').lstrip('v')
                            break
                        if package.get('name') == 'magento/product-enterprise-edition':
                            current_version = package.get('version', '').lstrip('v')
                            break
            except Exception as e:
                logger.warning(f"Error reading composer.lock: {e}")

        # Fall back to composer.json
        if not current_version and os.path.isfile(composer_json_path):
            try:
                with open(composer_json_path, 'r') as f:
                    composer_data = json.load(f)
                    require = composer_data.get('require', {})
                    version_str = require.get('magento/product-community-edition') or \
                                  require.get('magento/product-enterprise-edition', '')
                    # Parse version constraint (e.g., "2.4.6" or "^2.4.6")
                    current_version = version_str.lstrip('^~>=<').split(',')[0].strip()
            except Exception as e:
                logger.warning(f"Error reading composer.json: {e}")

        if not current_version:
            return {
                "current_version": "unknown",
                "latest_version": LATEST_MAGENTO_VERSION,
                "is_outdated": True,
                "error": "Could not determine Magento version"
            }

        # Compare versions
        is_outdated = current_version != LATEST_MAGENTO_VERSION
        versions_behind = 0

        # Calculate versions behind
        version_list = list(MAGENTO_VERSIONS.keys())
        if current_version in version_list:
            current_idx = version_list.index(current_version)
            versions_behind = current_idx
        elif is_outdated:
            versions_behind = len(version_list)  # Unknown old version

        return {
            "current_version": current_version,
            "latest_version": LATEST_MAGENTO_VERSION,
            "is_outdated": is_outdated,
            "versions_behind": versions_behind,
            "edition": "community"  # or enterprise based on package name
        }

    def _check_security(self, magento_root: str) -> Dict[str, Any]:
        """Check security status from database and filesystem."""
        result = {
            "vulnerabilities": {},
            "risk_level": "low"
        }

        conn = self._get_db_connection()
        if conn:
            try:
                cursor = conn.cursor(dictionary=True)

                # Check brute force protection (admin lockout settings)
                cursor.execute("""
                    SELECT path, value FROM core_config_data
                    WHERE path IN (
                        'admin/captcha/enable',
                        'admin/security/lockout_failures',
                        'admin/security/lockout_threshold',
                        'admin/security/password_lifetime'
                    )
                """)

                security_settings = {row['path']: row['value'] for row in cursor.fetchall()}

                brute_force_protection = (
                    security_settings.get('admin/captcha/enable') == '1' or
                    int(security_settings.get('admin/security/lockout_failures', '0') or '0') > 0
                )

                result['vulnerabilities']['brute_force_protection'] = brute_force_protection

                cursor.close()
                conn.close()

            except Exception as e:
                logger.error(f"Security check failed: {e}")
                result['error'] = str(e)
                if conn:
                    conn.close()

        # Check if admin URL is customized (read from env.php)
        admin_custom_url = False
        admin_frontend_name = 'admin'
        try:
            env_php_path = os.path.join(magento_root, 'app', 'etc', 'env.php')
            if os.path.exists(env_php_path):
                with open(env_php_path, 'r') as f:
                    content = f.read()
                    # Look for 'backend' => ['frontName' => 'admin_14ecus']
                    frontend_match = re.search(r"'frontName'\s*=>\s*'([^']+)'", content)
                    if frontend_match:
                        admin_frontend_name = frontend_match.group(1)
                        admin_custom_url = admin_frontend_name != 'admin'
                        logger.debug(f"Found admin frontName: '{admin_frontend_name}', customized: {admin_custom_url}")
                    else:
                        logger.debug("No frontName found in env.php, using default 'admin'")
        except Exception as e:
            logger.debug(f"Could not read frontName from env.php: {e}")

        result['vulnerabilities']['admin_url_customized'] = admin_custom_url
        result['vulnerabilities']['admin_frontend_name'] = admin_frontend_name

        # Check for common security issues in filesystem
        var_cache_exposed = os.path.exists(os.path.join(magento_root, 'pub', 'var'))
        result['vulnerabilities']['cache_leak'] = var_cache_exposed

        # Determine risk level
        vulns = result['vulnerabilities']
        if vulns.get('cache_leak'):
            result['risk_level'] = 'critical'
        elif not vulns.get('brute_force_protection', True) or not vulns.get('admin_url_customized', True):
            result['risk_level'] = 'high'
        elif not vulns.get('admin_url_customized', True):
            result['risk_level'] = 'medium'

        return result

    def _check_database_size(self) -> Dict[str, Any]:
        """Check database sizes from information_schema - all databases and Magento tables."""
        conn = self._get_db_connection()
        if not conn:
            return {"error": "Database connection not available"}

        try:
            cursor = conn.cursor(dictionary=True)
            credentials = self._get_db_credentials()
            db_name = credentials.get('dbname')

            # Get ALL database sizes
            logger.debug("Querying all database sizes")
            cursor.execute("""
                SELECT
                    table_schema as database_name,
                    SUM(data_length + index_length) as total_size
                FROM information_schema.TABLES
                WHERE table_schema NOT IN ('information_schema', 'mysql', 'performance_schema', 'sys')
                GROUP BY table_schema
                ORDER BY total_size DESC
            """)

            all_databases = []
            magento_db_size = 0
            for row in cursor.fetchall():
                database_name = row.get('database_name') or row.get('DATABASE_NAME', 'unknown')
                db_size_val = row.get('total_size') or row.get('TOTAL_SIZE', 0)
                try:
                    db_size = int(float(db_size_val)) if db_size_val else 0
                except (ValueError, TypeError):
                    db_size = 0

                all_databases.append({
                    "database": database_name,
                    "size": format_bytes(db_size),
                    "size_bytes": db_size,
                    "is_magento": database_name == db_name
                })

                # Track Magento database size
                if database_name == db_name:
                    magento_db_size = db_size

            logger.debug(f"Found {len(all_databases)} databases")

            # Get largest tables in Magento database
            cursor.execute("""
                SELECT
                    TABLE_NAME,
                    data_length + index_length as size
                FROM information_schema.TABLES
                WHERE table_schema = %s
                ORDER BY size DESC
                LIMIT 10
            """, (db_name,))

            largest_tables = []
            for row in cursor.fetchall():
                table_name = row.get('TABLE_NAME') or row.get('table_name', 'unknown')
                table_size = row.get('size', 0)
                largest_tables.append({
                    "table": table_name,
                    "size": format_bytes(int(table_size)),
                    "size_bytes": int(table_size)
                })

            cursor.close()
            conn.close()

            return {
                "magento_database": db_name,
                "magento_database_size_bytes": magento_db_size,
                "magento_database_size_human": format_bytes(magento_db_size),
                "all_databases": all_databases,
                "largest_tables": largest_tables
            }

        except Exception as e:
            logger.error(f"Database size check failed: {e}")
            if conn:
                conn.close()
            return {"error": str(e)}

    def _check_large_folders(self, magento_root: str) -> Dict[str, Any]:
        """Check for large folders and largest individual files in Magento installation."""
        # Common large directories in Magento
        folders_to_check = [
            'pub/media',
            'pub/media/catalog/product',
            'pub/static',
            'var',
            'var/log',
            'var/cache',
            'var/page_cache',
            'generated',
            'generated/code',
            'vendor',
        ]

        folder_sizes = []
        total_size = 0

        for folder in folders_to_check:
            folder_path = os.path.join(magento_root, folder)
            if os.path.isdir(folder_path):
                size, file_count = get_directory_size(folder_path)
                folder_sizes.append({
                    "path": folder,
                    "size": format_bytes(size),
                    "size_bytes": size,
                    "files": file_count
                })
                # Only add to total for top-level directories
                if folder.count('/') == 0 or folder in ['pub/media', 'pub/static']:
                    total_size += size

        # Sort by size and take top 5
        folder_sizes.sort(key=lambda x: x['size_bytes'], reverse=True)

        # Find top 10 largest individual files
        largest_files = self._find_largest_files(magento_root, limit=10)

        return {
            "large_folders": folder_sizes[:5],
            "all_folders": folder_sizes,
            "largest_files": largest_files,
            "total_magento_size": format_bytes(total_size),
            "total_magento_size_bytes": total_size
        }

    def _find_largest_files(self, magento_root: str, limit: int = 10) -> list:
        """Find the largest individual files in Magento installation."""
        try:
            import heapq

            # Directories to scan for large files
            scan_dirs = [
                'pub/media',
                'var/log',
                'var/report',
                'var/export',
                'var/import',
                'var/backups',
            ]

            file_heap = []  # Use heap to efficiently track top N files

            for scan_dir in scan_dirs:
                dir_path = os.path.join(magento_root, scan_dir)
                if not os.path.isdir(dir_path):
                    continue

                logger.debug(f"Scanning {scan_dir} for large files...")

                # Walk through directory
                for root, dirs, files in os.walk(dir_path):
                    # Skip hidden directories and cache
                    dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['cache', 'tmp']]

                    for filename in files:
                        try:
                            file_path = os.path.join(root, filename)
                            # Skip symlinks
                            if os.path.islink(file_path):
                                continue

                            file_size = os.path.getsize(file_path)

                            # Only track files >= 1MB
                            if file_size >= 1024 * 1024:
                                # Store negative size for min heap (to get largest)
                                # Keep relative path from magento root
                                relative_path = os.path.relpath(file_path, magento_root)

                                if len(file_heap) < limit:
                                    heapq.heappush(file_heap, (file_size, relative_path))
                                elif file_size > file_heap[0][0]:
                                    heapq.heapreplace(file_heap, (file_size, relative_path))

                        except (OSError, PermissionError) as e:
                            # Skip files we can't access
                            logger.debug(f"Skipping file {filename}: {e}")
                            continue

            # Convert heap to sorted list (largest first)
            largest_files = [
                {
                    "path": path,
                    "size": format_bytes(size),
                    "size_bytes": size
                }
                for size, path in sorted(file_heap, reverse=True)
            ]

            logger.debug(f"Found {len(largest_files)} large files")
            return largest_files

        except Exception as e:
            logger.error(f"Failed to find largest files: {e}")
            return []

    def _check_var_directory(self, magento_root: str) -> Dict[str, Any]:
        """Check var/ directory breakdown."""
        var_path = os.path.join(magento_root, 'var')

        if not os.path.isdir(var_path):
            return {"error": "var/ directory not found"}

        # Subdirectories to check
        subdirs = ['cache', 'page_cache', 'session', 'log', 'report', 'tmp', 'export', 'import', 'view_preprocessed']

        breakdown = {}
        total_size = 0

        for subdir in subdirs:
            subdir_path = os.path.join(var_path, subdir)
            if os.path.isdir(subdir_path):
                size, file_count = get_directory_size(subdir_path)
                breakdown[subdir] = {
                    "size": format_bytes(size),
                    "size_bytes": size,
                    "files": file_count
                }
                total_size += size

        return {
            "var_breakdown": breakdown,
            "total_var_size": format_bytes(total_size),
            "total_var_size_bytes": total_size
        }

    def _check_cache_status(self) -> Dict[str, Any]:
        """Check Magento cache status from app/etc/env.php file.

        In Magento 2, cache configuration is stored in env.php under 'cache_types' key,
        not in the database like Magento 1.
        """
        magento_root = self.config.get('magento_root', '')
        env_php_path = os.path.join(magento_root, 'app', 'etc', 'env.php')

        if not os.path.isfile(env_php_path):
            return {"error": f"env.php not found at: {env_php_path}"}

        try:
            with open(env_php_path, 'r', encoding='utf-8') as f:
                content = f.read()

            logger.info(f"Reading cache status from: {env_php_path}")

            # Cache type labels (human-readable names)
            cache_labels = {
                'config': 'Configuration',
                'layout': 'Layouts',
                'block_html': 'Blocks HTML output',
                'collections': 'Collections Data',
                'reflection': 'Reflection Data',
                'db_ddl': 'Database DDL operations',
                'compiled_config': 'Compiled Config',
                'eav': 'EAV types and attributes',
                'customer_notification': 'Customer Notification',
                'config_integration': 'Integrations Configuration',
                'config_integration_api': 'Integrations API Configuration',
                'full_page': 'Page Cache (FPC)',
                'config_webservice': 'Web Services Configuration',
                'translate': 'Translations',
                'vertex': 'Vertex',
                'target_rule': 'Target Rule',
                'amasty_shopby': 'Amasty Shopby',
                'google_product': 'Google Product Feed',
            }

            cache_types = []
            enabled_count = 0
            disabled_count = 0

            # Parse cache_types from env.php
            # Format: 'cache_types' => ['config' => 1, 'layout' => 1, ...]
            # Find the cache_types array section
            cache_types_match = re.search(
                r"'cache_types'\s*=>\s*\[\s*(.*?)\s*\]",
                content,
                re.DOTALL
            )

            if cache_types_match:
                cache_section = cache_types_match.group(1)
                logger.debug(f"Found cache_types section: {cache_section[:200]}...")

                # Extract individual cache type entries: 'cache_id' => 0|1
                cache_entries = re.findall(
                    r"'([^']+)'\s*=>\s*(\d+)",
                    cache_section
                )

                logger.info(f"Found {len(cache_entries)} cache types in env.php")

                for cache_id, status_val in cache_entries:
                    is_enabled = int(status_val) == 1

                    if is_enabled:
                        enabled_count += 1
                    else:
                        disabled_count += 1

                    cache_types.append({
                        "id": cache_id,
                        "label": cache_labels.get(cache_id, cache_id.replace('_', ' ').title()),
                        "status": "ENABLED" if is_enabled else "DISABLED"
                    })
            else:
                logger.warning("Could not find 'cache_types' section in env.php")
                return {"error": "cache_types section not found in env.php"}

            return {
                "cache_types": cache_types,
                "total": len(cache_types),
                "enabled_count": enabled_count,
                "disabled_count": disabled_count,
                "all_enabled": disabled_count == 0
            }

        except Exception as e:
            import traceback
            logger.error(f"Cache status check failed: {e}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            return {"error": str(e)}

    def _check_indexer_status(self) -> Dict[str, Any]:
        """Check Magento indexer status from indexer_state table."""
        conn = self._get_db_connection()
        if not conn:
            return {"error": "Database connection not available"}

        try:
            cursor = conn.cursor(dictionary=True)

            # Get table prefix
            magento_root = self.config.get('magento_root', '')
            env_php_path = os.path.join(magento_root, 'app', 'etc', 'env.php')
            table_prefix = ''
            try:
                with open(env_php_path, 'r') as f:
                    content = f.read()
                    prefix_match = re.search(r"'table_prefix'\s*=>\s*'([^']*)'", content)
                    if prefix_match:
                        table_prefix = prefix_match.group(1)
            except Exception:
                pass

            # Query indexer state
            # status: valid, working, invalid
            # mode: scheduled, real_time (Update on Save)
            query = f"""
                SELECT indexer_id, status, updated
                FROM {table_prefix}indexer_state
                ORDER BY indexer_id ASC
            """

            logger.debug(f"Querying indexer status: {query}")
            cursor.execute(query)
            rows = cursor.fetchall()

            # Also get indexer mode from mview_state (if available)
            mode_query = f"""
                SELECT view_id, mode
                FROM {table_prefix}mview_state
            """
            indexer_modes = {}
            try:
                cursor.execute(mode_query)
                mode_rows = cursor.fetchall()
                for row in mode_rows:
                    view_id = row.get('view_id') or row.get('VIEW_ID', '')
                    mode = row.get('mode') or row.get('MODE', 'enabled')
                    indexer_modes[view_id] = mode
            except Exception as e:
                logger.debug(f"Could not query mview_state: {e}")

            indexers = []
            valid_count = 0
            invalid_count = 0
            working_count = 0

            # Indexer labels (human-readable names)
            indexer_labels = {
                'design_config_grid': 'Design Config Grid',
                'customer_grid': 'Customer Grid',
                'catalog_category_product': 'Category Products',
                'catalog_product_category': 'Product Categories',
                'catalogrule_rule': 'Catalog Rule Product',
                'catalog_product_attribute': 'Product EAV',
                'cataloginventory_stock': 'Stock',
                'inventory': 'Inventory',
                'catalogrule_product': 'Catalog Product Rule',
                'catalog_product_price': 'Product Price',
                'catalogsearch_fulltext': 'Catalog Search',
                'targetrule_product_rule': 'Target Rule Product',
                'targetrule_rule_product': 'Target Rule Rule',
                'salesrule_rule': 'Sales Rule',
            }

            # Status mapping for display
            status_display = {
                'valid': 'READY',
                'invalid': 'REINDEX REQUIRED',
                'working': 'PROCESSING'
            }

            for row in rows:
                indexer_id = row.get('indexer_id') or row.get('INDEXER_ID', '')
                status = row.get('status') or row.get('STATUS', 'valid')
                updated = row.get('updated') or row.get('UPDATED')

                # Get mode (default to "Update on Save" if not in mview_state)
                mode = indexer_modes.get(indexer_id, 'real_time')
                mode_display = 'Update by Schedule' if mode == 'enabled' else 'Update on Save'

                if status == 'valid':
                    valid_count += 1
                elif status == 'invalid':
                    invalid_count += 1
                elif status == 'working':
                    working_count += 1

                # Format updated timestamp
                updated_str = None
                if updated:
                    if hasattr(updated, 'strftime'):
                        updated_str = updated.strftime('%Y-%m-%d %H:%M:%S')
                    else:
                        updated_str = str(updated)

                indexers.append({
                    "id": indexer_id,
                    "label": indexer_labels.get(indexer_id, indexer_id.replace('_', ' ').title()),
                    "status": status_display.get(status, status.upper()),
                    "status_code": status,
                    "mode": mode_display,
                    "updated": updated_str
                })

            cursor.close()
            conn.close()

            return {
                "indexers": indexers,
                "total": len(indexers),
                "valid_count": valid_count,
                "invalid_count": invalid_count,
                "working_count": working_count,
                "all_valid": invalid_count == 0 and working_count == 0,
                "reindex_required": invalid_count > 0
            }

        except Exception as e:
            logger.error(f"Indexer status check failed: {e}")
            if conn:
                conn.close()
            return {"error": str(e)}
