"""
Combined System Health check implementation.

Checks CPU, Memory, Disk, and important service status in a single unified check.
Also includes top processes by CPU and Memory usage.
"""

import logging
import subprocess
import time
from typing import Dict, Any, List, Optional

import psutil

from ..base import BaseCheck, CheckResult, CheckStatus
from ..registry import CheckRegistry

logger = logging.getLogger(__name__)

# Default services to check (can be overridden via config)
DEFAULT_SERVICES = [
    'httpd', 'apache2', 'nginx',  # Web servers
    'mysqld', 'mariadb', 'mysql',  # MySQL/MariaDB
    'redis', 'redis-server',  # Redis
    'opensearch', 'elasticsearch',  # Search engines
    'crond', 'cron',  # Cron
    'php-fpm', 'php8.1-fpm', 'php8.2-fpm', 'php8.3-fpm',  # PHP-FPM
    'rabbitmq-server',  # RabbitMQ
    'varnish',  # Varnish
    'memcached',  # Memcached
    'postfix',  # Mail
    'sshd',  # SSH
]

# Mutually exclusive service groups - only one from each group should be shown
# (e.g., if apache2 is running, don't show nginx even if installed)
EXCLUSIVE_SERVICE_GROUPS = [
    ['httpd', 'apache2', 'nginx'],  # Web servers - typically only one runs
    ['opensearch', 'elasticsearch'],  # Search engines - typically only one runs
    ['mysqld', 'mariadb', 'mysql'],  # Database - these are variants/aliases
    ['redis', 'redis-server'],  # Redis - package name varies by distro
    ['crond', 'cron'],  # Cron - package name varies by distro
]


def format_bytes(bytes_value: int) -> str:
    """Format bytes to human-readable string."""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_value < 1024:
            return f"{bytes_value:.2f} {unit}"
        bytes_value /= 1024
    return f"{bytes_value:.2f} PB"


@CheckRegistry.register('SYSTEM_HEALTH')
class SystemHealthCheck(BaseCheck):
    """
    Combined system health check for CPU, Memory, Disk, and Service status.

    Configuration options:
        cpu_warning_threshold: CPU percentage for warning (default: 80)
        cpu_critical_threshold: CPU percentage for critical (default: 95)
        memory_warning_threshold: Memory percentage for warning (default: 80)
        memory_critical_threshold: Memory percentage for critical (default: 95)
        disk_warning_threshold: Disk percentage for warning (default: 80)
        disk_critical_threshold: Disk percentage for critical (default: 90)
        disk_exclude_types: Filesystem types to exclude (default: ['tmpfs', 'devtmpfs', 'squashfs', 'overlay'])
        include_processes: Include top processes by CPU/Memory (default: True)
        process_count: Number of top processes to return (default: 25)
        include_services: Include service status check (default: True)
        services: List of service names to check (default: common web services)
        critical_services: Services that trigger critical status if down (default: ['httpd', 'apache2', 'nginx', 'mysqld', 'mariadb'])
    """

    DEFAULT_CPU_WARNING = 80
    DEFAULT_CPU_CRITICAL = 95
    DEFAULT_MEMORY_WARNING = 80
    DEFAULT_MEMORY_CRITICAL = 95
    DEFAULT_DISK_WARNING = 80
    DEFAULT_DISK_CRITICAL = 90
    DEFAULT_EXCLUDE_TYPES = ['tmpfs', 'devtmpfs', 'squashfs', 'overlay']
    DEFAULT_PROCESS_COUNT = 25
    DEFAULT_CRITICAL_SERVICES = ['httpd', 'apache2', 'nginx', 'mysqld', 'mariadb', 'mysql']

    @property
    def name(self) -> str:
        return "System Health"

    @property
    def category(self) -> str:
        return "infrastructure"

    def execute(self) -> CheckResult:
        """
        Execute combined system health check.

        Returns:
            CheckResult with CPU, Memory, Disk, Network, and Process information
        """
        start_time = time.time()

        try:
            # Get thresholds from config
            cpu_warning = self.config.get('cpu_warning_threshold', self.DEFAULT_CPU_WARNING)
            cpu_critical = self.config.get('cpu_critical_threshold', self.DEFAULT_CPU_CRITICAL)
            memory_warning = self.config.get('memory_warning_threshold', self.DEFAULT_MEMORY_WARNING)
            memory_critical = self.config.get('memory_critical_threshold', self.DEFAULT_MEMORY_CRITICAL)
            disk_warning = self.config.get('disk_warning_threshold', self.DEFAULT_DISK_WARNING)
            disk_critical = self.config.get('disk_critical_threshold', self.DEFAULT_DISK_CRITICAL)
            disk_exclude_types = self.config.get('disk_exclude_types', self.DEFAULT_EXCLUDE_TYPES)
            include_processes = self.config.get('include_processes', True)
            process_count = self.config.get('process_count', self.DEFAULT_PROCESS_COUNT)
            include_services = self.config.get('include_services', True)
            services_to_check = self.config.get('services', DEFAULT_SERVICES)
            critical_services = self.config.get('critical_services', self.DEFAULT_CRITICAL_SERVICES)

            # Collect all metrics
            cpu_data = self._get_cpu_info(cpu_warning, cpu_critical)
            memory_data = self._get_memory_info(memory_warning, memory_critical)
            disk_data = self._get_disk_info(disk_warning, disk_critical, disk_exclude_types)

            # Collect optional metrics
            services_data = self._get_services_status(services_to_check, critical_services) if include_services else None
            processes_data = self._get_top_processes(process_count) if include_processes else None

            duration = int((time.time() - start_time) * 1000)

            # Calculate overall status (worst of all)
            statuses = [cpu_data['status'], memory_data['status'], disk_data['status']]
            if services_data and services_data.get('status'):
                statuses.append(services_data['status'])

            if 'critical' in statuses:
                overall_status = CheckStatus.CRITICAL
            elif 'warning' in statuses:
                overall_status = CheckStatus.WARNING
            else:
                overall_status = CheckStatus.PASSED

            # Calculate combined score (weighted average)
            # CPU: 25%, Memory: 25%, Disk: 30%, Services: 20%
            if services_data:
                combined_score = int(
                    cpu_data['score'] * 0.25 +
                    memory_data['score'] * 0.25 +
                    disk_data['score'] * 0.30 +
                    services_data.get('score', 100) * 0.20
                )
            else:
                combined_score = int(
                    cpu_data['score'] * 0.30 +
                    memory_data['score'] * 0.30 +
                    disk_data['score'] * 0.40
                )

            # Build summary message
            issues = []
            if cpu_data['status'] != 'passed':
                issues.append(f"CPU {cpu_data['percent']:.1f}%")
            if memory_data['status'] != 'passed':
                issues.append(f"Memory {memory_data['percent']:.1f}%")
            if disk_data['status'] != 'passed':
                issues.append(f"Disk {disk_data['max_percent']:.1f}%")
            if services_data and services_data.get('status') != 'passed':
                down_count = services_data.get('down_count', 0)
                issues.append(f"{down_count} service(s) down")

            if issues:
                message = f"Issues detected: {', '.join(issues)}"
            else:
                message = f"System healthy - CPU: {cpu_data['percent']:.1f}%, Memory: {memory_data['percent']:.1f}%, Disk: {disk_data['max_percent']:.1f}%"

            details: Dict[str, Any] = {
                'cpu': cpu_data,
                'memory': memory_data,
                'disk': disk_data,
                'thresholds': {
                    'cpu': {'warning': cpu_warning, 'critical': cpu_critical},
                    'memory': {'warning': memory_warning, 'critical': memory_critical},
                    'disk': {'warning': disk_warning, 'critical': disk_critical},
                },
            }

            if services_data:
                details['services'] = services_data

            if processes_data:
                details['processes'] = processes_data

            return CheckResult(
                status=overall_status,
                score=combined_score,
                message=message,
                details=details,
                duration=duration,
            )

        except Exception as e:
            duration = int((time.time() - start_time) * 1000)
            logger.error(f"System health check failed: {e}")
            return CheckResult(
                status=CheckStatus.ERROR,
                score=0,
                message=f"Check failed: {str(e)}",
                duration=duration,
            )

    def _get_cpu_info(self, warning_threshold: int, critical_threshold: int) -> Dict[str, Any]:
        """Get CPU usage information."""
        # Get CPU percentage (average over 1 second)
        cpu_percent = psutil.cpu_percent(interval=1)

        # Get load averages (1, 5, 15 minutes)
        try:
            load_avg = psutil.getloadavg()
        except (AttributeError, OSError):
            # Windows doesn't support getloadavg
            load_avg = (0, 0, 0)

        # Get CPU count
        cpu_count = psutil.cpu_count()
        cpu_count_logical = psutil.cpu_count(logical=True)

        # Determine status
        if cpu_percent >= critical_threshold:
            status = 'critical'
            score = 30
        elif cpu_percent >= warning_threshold:
            status = 'warning'
            score = 70
        else:
            status = 'passed'
            score = 100

        return {
            'percent': cpu_percent,
            'load_avg_1m': load_avg[0],
            'load_avg_5m': load_avg[1],
            'load_avg_15m': load_avg[2],
            'cores_physical': cpu_count,
            'cores_logical': cpu_count_logical,
            'status': status,
            'score': score,
        }

    def _get_memory_info(self, warning_threshold: int, critical_threshold: int) -> Dict[str, Any]:
        """Get memory usage information."""
        memory = psutil.virtual_memory()
        swap = psutil.swap_memory()

        memory_percent = memory.percent

        # Determine status
        if memory_percent >= critical_threshold:
            status = 'critical'
            score = 30
        elif memory_percent >= warning_threshold:
            status = 'warning'
            score = 70
        else:
            status = 'passed'
            score = 100

        return {
            'percent': memory_percent,
            'total_gb': round(memory.total / (1024**3), 2),
            'used_gb': round(memory.used / (1024**3), 2),
            'available_gb': round(memory.available / (1024**3), 2),
            'swap_percent': swap.percent,
            'swap_total_gb': round(swap.total / (1024**3), 2),
            'swap_used_gb': round(swap.used / (1024**3), 2),
            'status': status,
            'score': score,
        }

    def _get_disk_info(
        self,
        warning_threshold: int,
        critical_threshold: int,
        exclude_types: List[str]
    ) -> Dict[str, Any]:
        """Get disk usage information."""
        disks = []
        max_percent = 0
        worst_status = 'passed'
        worst_score = 100

        for partition in psutil.disk_partitions(all=False):
            if partition.fstype in exclude_types:
                continue

            try:
                usage = psutil.disk_usage(partition.mountpoint)
                percent = usage.percent

                # Determine status for this disk
                if percent >= critical_threshold:
                    disk_status = 'critical'
                    disk_score = 30
                elif percent >= warning_threshold:
                    disk_status = 'warning'
                    disk_score = 70
                else:
                    disk_status = 'passed'
                    disk_score = 100

                # Track worst
                if percent > max_percent:
                    max_percent = percent
                    worst_status = disk_status
                    worst_score = disk_score

                disks.append({
                    'mountpoint': partition.mountpoint,
                    'device': partition.device,
                    'fstype': partition.fstype,
                    'percent': percent,
                    'total_gb': round(usage.total / (1024**3), 2),
                    'used_gb': round(usage.used / (1024**3), 2),
                    'free_gb': round(usage.free / (1024**3), 2),
                    'status': disk_status,
                })
            except (OSError, PermissionError) as e:
                logger.warning(f"Cannot access {partition.mountpoint}: {e}")

        return {
            'disks': disks,
            'max_percent': max_percent,
            'status': worst_status,
            'score': worst_score,
        }

    def _get_services_status(self, services: List[str], critical_services: List[str]) -> Dict[str, Any]:
        """
        Check the status of important system services.

        For mutually exclusive services (e.g., apache2 vs nginx), only shows
        the one that is actually running or enabled, not both.

        Args:
            services: List of service names to check
            critical_services: List of services that trigger critical status if down

        Returns:
            Dictionary with service status information
        """
        service_statuses = []
        running_count = 0
        down_count = 0
        critical_down = []

        # Track which services from exclusive groups to include
        services_to_include = self._filter_exclusive_services(services)

        for service in services_to_include:
            status_info = self._check_service(service)
            if status_info:
                service_statuses.append(status_info)
                if status_info['is_running']:
                    running_count += 1
                else:
                    down_count += 1
                    # Check if this is a critical service
                    if service in critical_services:
                        critical_down.append(service)

        # Determine overall status
        if critical_down:
            status = 'critical'
            score = 30
        elif down_count > 0:
            status = 'warning'
            score = 70
        else:
            status = 'passed'
            score = 100

        return {
            'services': service_statuses,
            'running_count': running_count,
            'down_count': down_count,
            'total_checked': len(service_statuses),
            'critical_down': critical_down,
            'status': status,
            'score': score,
        }

    def _filter_exclusive_services(self, services: List[str]) -> List[str]:
        """
        Filter services to handle mutually exclusive groups.

        For groups like [apache2, nginx], only include the service that is
        actually running or enabled, not alternatives that may be installed
        but not in use.

        Args:
            services: List of service names to check

        Returns:
            Filtered list of services to actually check
        """
        result = []
        processed_in_group = set()

        for service in services:
            # Check if this service belongs to an exclusive group
            group = self._get_service_group(service)

            if group:
                # Skip if we already processed this group
                group_key = tuple(sorted(group))
                if group_key in processed_in_group:
                    continue
                processed_in_group.add(group_key)

                # Find which service(s) from this group are actually active or enabled
                active_services = self._get_active_services_from_group(group, services)
                result.extend(active_services)
            else:
                # Not in any exclusive group, add directly
                result.append(service)

        return result

    def _get_service_group(self, service_name: str) -> Optional[List[str]]:
        """
        Get the exclusive group a service belongs to, if any.

        Args:
            service_name: Name of the service

        Returns:
            List of services in the same exclusive group, or None
        """
        for group in EXCLUSIVE_SERVICE_GROUPS:
            if service_name in group:
                return group
        return None

    def _get_active_services_from_group(self, group: List[str], requested_services: List[str]) -> List[str]:
        """
        From a group of mutually exclusive services, return only those that
        are actually running or enabled on the system.

        Args:
            group: List of mutually exclusive service names
            requested_services: The original list of services to check

        Returns:
            List of services from the group that should be shown
        """
        active = []
        enabled_not_running = []

        for service in group:
            # Only consider services that were in the original request
            if service not in requested_services:
                continue

            try:
                result = subprocess.run(
                    ['systemctl', 'show', service, '--property=LoadState,ActiveState,UnitFileState'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )

                if result.returncode != 0:
                    continue

                props = {}
                for line in result.stdout.strip().split('\n'):
                    if '=' in line:
                        key, value = line.split('=', 1)
                        props[key] = value

                load_state = props.get('LoadState', 'not-found')
                active_state = props.get('ActiveState', 'unknown')
                unit_file_state = props.get('UnitFileState', '')

                # Skip if not loaded
                if load_state in ['not-found', 'masked']:
                    continue

                # If running, this is the one to show
                if active_state == 'active':
                    active.append(service)
                # If enabled but not running, track it
                elif unit_file_state == 'enabled':
                    enabled_not_running.append(service)

            except Exception as e:
                logger.debug(f"Error checking service {service} for group filtering: {e}")
                continue

        # Prefer running services, fall back to enabled services
        if active:
            return active
        elif enabled_not_running:
            return enabled_not_running
        else:
            # No service from group is running or enabled
            return []

    def _check_service(self, service_name: str) -> Optional[Dict[str, Any]]:
        """
        Check if a specific service is running.

        Shows all services that are installed on the system, including disabled ones.
        Only skips services that don't exist (not-found) or are masked.

        Args:
            service_name: Name of the service to check

        Returns:
            Dictionary with service status or None if service not installed
        """
        try:
            # Check if service is installed by checking its LoadState
            # A service is "installed" if LoadState is "loaded" (not "not-found")
            load_result = subprocess.run(
                ['systemctl', 'show', service_name, '--property=LoadState,ActiveState,UnitFileState'],
                capture_output=True,
                text=True,
                timeout=5
            )

            if load_result.returncode != 0:
                return None

            # Parse the output
            props = {}
            for line in load_result.stdout.strip().split('\n'):
                if '=' in line:
                    key, value = line.split('=', 1)
                    props[key] = value

            load_state = props.get('LoadState', 'not-found')
            active_state = props.get('ActiveState', 'unknown')

            # Skip services that are not loaded (package not installed)
            if load_state == 'not-found':
                return None

            # Skip services that are masked (intentionally hidden)
            if load_state == 'masked':
                return None

            # Show all installed services (including disabled ones)
            # A service is considered "installed" if LoadState is 'loaded'
            is_active = active_state == 'active'
            status_text = active_state

            # If service is active, get more details
            started_at = None
            if is_active:
                status_result = subprocess.run(
                    ['systemctl', 'show', service_name, '--property=ActiveEnterTimestamp'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if status_result.returncode == 0 and status_result.stdout:
                    timestamp_line = status_result.stdout.strip()
                    if '=' in timestamp_line:
                        started_at = timestamp_line.split('=', 1)[1].strip()

            return {
                'name': service_name,
                'is_running': is_active,
                'status': status_text,
                'started_at': started_at,
            }

        except subprocess.TimeoutExpired:
            logger.warning(f"Timeout checking service {service_name}")
            return None
        except FileNotFoundError:
            # systemctl not available, try alternative methods
            return self._check_service_alternative(service_name)
        except Exception as e:
            logger.debug(f"Error checking service {service_name}: {e}")
            return None

    def _check_service_alternative(self, service_name: str) -> Optional[Dict[str, Any]]:
        """
        Alternative method to check service status (for systems without systemctl).

        Args:
            service_name: Name of the service to check

        Returns:
            Dictionary with service status or None if not found
        """
        try:
            # Try using 'service' command
            result = subprocess.run(
                ['service', service_name, 'status'],
                capture_output=True,
                text=True,
                timeout=5
            )

            # Check if service is running based on return code and output
            is_running = result.returncode == 0 or 'running' in result.stdout.lower()

            if result.returncode == 0 or 'unrecognized' not in result.stderr.lower():
                return {
                    'name': service_name,
                    'is_running': is_running,
                    'status': 'running' if is_running else 'stopped',
                    'started_at': None,
                }

            return None

        except Exception:
            # Check if process is running by name
            for proc in psutil.process_iter(['name']):
                try:
                    if service_name in proc.info['name'].lower():
                        return {
                            'name': service_name,
                            'is_running': True,
                            'status': 'running',
                            'started_at': None,
                        }
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            return None

    def _get_top_processes(self, count: int = 25) -> Dict[str, Any]:
        """
        Get top processes by CPU and Memory usage.

        Args:
            count: Number of top processes to return (default 25)

        Returns:
            Dictionary with top processes by CPU and Memory
        """
        processes = []

        # Iterate through all processes
        for proc in psutil.process_iter(['pid', 'name', 'username', 'cpu_percent', 'memory_percent', 'cmdline']):
            try:
                pinfo = proc.info
                # Skip system processes with no name
                if not pinfo['name']:
                    continue

                # Get command line (truncate if too long)
                cmdline = ' '.join(pinfo['cmdline']) if pinfo['cmdline'] else pinfo['name']
                if len(cmdline) > 200:
                    cmdline = cmdline[:197] + '...'

                processes.append({
                    'pid': pinfo['pid'],
                    'name': pinfo['name'],
                    'user': pinfo['username'] or 'N/A',
                    'cpu_percent': pinfo['cpu_percent'] or 0.0,
                    'memory_percent': pinfo['memory_percent'] or 0.0,
                    'command': cmdline,
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

        # Sort by CPU and get top N
        top_by_cpu = sorted(processes, key=lambda p: p['cpu_percent'], reverse=True)[:count]

        # Sort by Memory and get top N
        top_by_memory = sorted(processes, key=lambda p: p['memory_percent'], reverse=True)[:count]

        # Format percentages to 1 decimal place
        for p in top_by_cpu:
            p['cpu_percent'] = round(p['cpu_percent'], 1)
            p['memory_percent'] = round(p['memory_percent'], 1)

        for p in top_by_memory:
            p['cpu_percent'] = round(p['cpu_percent'], 1)
            p['memory_percent'] = round(p['memory_percent'], 1)

        return {
            'top_by_cpu': top_by_cpu,
            'top_by_memory': top_by_memory,
        }
