"""
HexaScan Monitoring Agent

A lightweight Python agent for monitoring server health metrics,
analyzing logs, and executing checks on client servers.
"""

__version__ = "1.0.0"
